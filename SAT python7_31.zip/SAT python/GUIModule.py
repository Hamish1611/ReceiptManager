
#The GUI module will include code required to run the GUI, including the different pages, buttons, text boxes, etc.
import tkinter as tk
import functions
from tkinter import font
import tkinter.messagebox as messagebox
from PIL import Image, ImageTk
#Imports tkinter libaries to be used for GUI.
class GUIWindow:
    """
    Uses a class to easily change values within the GUI

    Attributes:
    None
    
    """

    def __init__(self):
        """
        Initialises GUI Class, including background colour, textsize, automatic fullscreen and an exit bind.

        Parameters:
        None
        """
        self.tk = tk.Tk()
        logoutIcon = Image.open("data//UI_Images//logoutIcon.png")
        logoutIcon = logoutIcon.resize((70, 100))
        exitButton = Image.open("data//UI_Images//exitIcon.png")
        exitButton = exitButton.resize((70, 100))
        self.logoutButtonImg = ImageTk.PhotoImage(logoutIcon)
        self.exitButton = ImageTk.PhotoImage(exitButton)
        self.screenWidth = int(self.tk.winfo_screenwidth())
        self.screenHeight = int(self.tk.winfo_screenheight())
        self.tk.attributes('-fullscreen', True)
        self.tk.title("Receipt Sorter")
        self.tk.bind("<Escape>", lambda e:self.tk.destroy())
        self.tk["bg"] = "#3a414a"
        self.textsize = int(20)
        self.UID = None
        self.logInPage()
        self.tk.mainloop()
    def onClick(self, textbox, type):
        """
        Once user clicks on textbox field it removes the grey text explaining the textbox.
        
        Args:
        textbox (var) : Variable refering to a Textbox
        type (str) : The type string refers to the type of textbox (Password, Username, etc.)
                     
        """
        self.focusedIn = True
        if type == 'Username':  
            if textbox.get() == 'Username':
                textbox.delete(0, "end") 
                textbox.insert(0, '') 
                textbox.config(fg = 'black')  
        if type == 'Password':
            if textbox.get() == 'Password':
                textbox.delete(0, "end") 
                textbox.insert(0, '') 
                textbox.config(fg = 'black') 
        if type == 'securityQuestion':
            if textbox.get() == 'Security Question':
                textbox.delete(0, "end")
                textbox.insert(0, '') 
                textbox.config(fg = 'black') 
        if type == 'securityAnswer':
            if textbox.get() == 'Security Answer':
                textbox.delete(0, "end") 
                textbox.insert(0, '') 
                textbox.config(fg = 'black')  
        if type == 'New Password':
            if textbox.get() == 'New Password':
                textbox.delete(0, "end") 
                textbox.insert(0, '') 
                textbox.config(fg = 'black') 
        if type == 'New Username':
            if textbox.get() == 'New Username':
                textbox.delete(0, "end") 
                textbox.insert(0, '') 
                textbox.config(fg = 'black') 
    def focusout(self, textbox, type):
        self.focusedIn = False
        """
        Once user clicks out off the textbox with no text in the box the function overlays the type text on the textbox.
        
        Args:
        textbox (var) : Variable refering to a Textbox
        type (str) : The type string refers to the type of textbox (Password, Username, etc.)
                     
        """
        if type == 'Username':  
            if textbox.get() == '':
                textbox.insert(0, 'Username')
                textbox.config(fg = 'grey')
        if type == 'Password':  
            if textbox.get() == '':
                textbox.insert(0, 'Password')
                textbox.config(fg = 'grey')
        if type == 'securityQuestion':  
            if textbox.get() == '':
                textbox.insert(0, 'Security Question')
                textbox.config(fg = 'grey')
        if type == 'securityAnswer':  
            if textbox.get() == '':
                textbox.insert(0, 'Security Answer')
                textbox.config(fg = 'grey')
        if type == 'New Password':  
            if textbox.get() == '':
                textbox.insert(0, 'New Password')
                textbox.config(fg = 'grey')
        if type == 'New Username':  
            if textbox.get() == '':
                textbox.insert(0, 'New Username')
                textbox.config(fg = 'grey')
    def signUpAccountVerification(self, username, password, question, answer):
        """
        Verifies the sign up information by checking if the same user exists
        Args:

        """
        x = functions.createAccount(username, password, question, answer)
        if x == None:
            messagebox.showerror(title="Failed to make Account", message="User already exists")
        else:
            self.UID = x
            messagebox.showinfo(title="Account Created", message=f"Account: {username} was successfully created!")
            self.logInPage()
            

    def loginAccountVerification(self, *args):
        """
        Verifies login information in a different python functions module, checks files to see if username and password are the same.
        *args(): arguments passed by button.
        """

        errorText = tk.Label(self.tk, text="incorrect username or password!")
        errorText.configure(font=('Bold', int(self.textsize) - 5), bg="#3a414a", fg="#ff0000")
        f = font.Font(errorText, errorText.cget("font"))
        f.configure(underline=True)
        errorText.configure(font=f)
        account = functions.loginVerification(self.usernameSignInInput.get(), self.passwordSignInInput.get())
        
        print(account)
        if account == None:
            errorText.place(relx=0.5, rely=0.558, anchor='center')
        else:
            self.UID = account
            self.mainPage()
    def returnKeyCheck(self, *args):
        if self.focusedIn == True:
            self.tk.focus_set()
        else:
            self.loginAccountVerification()
    def clearPage(self):
        for frame in self.tk.winfo_children():
            frame.destroy()

    def signOut(self):
        """
        Removes set user ID on the program then returns to main menu
        """
        self.UID = None
        self.logInPage()
    def logInPage(self):
        self.clearPage()
        print(self.UID)
        if self.UID != None:
            self.mainPage()
        else:
            self.tk.bind("<Return>", self.returnKeyCheck)
            #Grey Banner placed at the top of the login Page
            banner = tk.Frame(self.tk, bg='#6f7681')
            banner.pack()
            banner.pack_propagate(False)
            banner.configure(width=self.screenWidth, height=100)
            self.tk.bind("<Button-1>", lambda event: event.widget.focus_set())
            
            #White header text attached to the banner on the login Page
            headerText = tk.Label(banner, text="Sign in")
            headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
            headerText.place(relx=0.5, rely=0.5, anchor='center')
            #Login Button with white text and grey background on login Page
            loginBtn = tk.Button(self.tk, text='Login', font=('Bold', self.textsize), command=self.loginAccountVerification)
            loginBtn.configure(width=20, height=1, bg='#6f7681', bd=0, fg='#ffffff')
            loginBtn.place(relx=0.5, rely=0.7, anchor='center')
            #Reset Password Button with white text and grey background on login Page
            resetPasswordBtn = tk.Button(self.tk, text='Forgot Password?', font=('Bold',self.textsize), command=self.forgotPassword)
            resetPasswordBtn.configure(width=13, height=1, bg='#6f7681', bd=0, fg='#ffffff')
            resetPasswordBtn.place(relx=0.4, rely=0.8, anchor='center')
            #Sign up button with white text and grey background on login page
            signUp = tk.Button(self.tk, text='Sign Up', font=('Bold',self.textsize), command=self.signUpPage)
            signUp.configure(width=13, height=1, bg='#6f7681', bd=0, fg='#ffffff')
            signUp.place(relx=0.6, rely=0.8, anchor='center')
            #Password Entry Box on login page 
            self.passwordSignInInput = tk.Entry(self.tk, bd=1,)
            self.passwordSignInInput.insert(0, "Password")
            self.passwordSignInInput.place(relx=0.5, rely=0.5, anchor='center', height=60, width=330)
            self.passwordSignInInput.configure(justify="center")
            self.passwordSignInInput.configure(fg='grey')
            self.passwordSignInInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.passwordSignInInput, type='Password'))
            self.passwordSignInInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.passwordSignInInput, type='Password'))
            #Username Entry Box on login page
            self.usernameSignInInput = tk.Entry(self.tk, bd=1)
            self.usernameSignInInput.insert(0, "Username")
            self.usernameSignInInput.place(relx=0.5, rely=0.4, anchor='center', height=60, width=330)
            self.usernameSignInInput.configure(justify="center")
            self.usernameSignInInput.configure(fg='grey')
            self.usernameSignInInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.usernameSignInInput, type="Username"))
            self.usernameSignInInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.usernameSignInInput, type="Username"))

    def signUpPage(self):
        """
        Signup page allows user to create an account
        """
        #Removes widgets present on the page.
        self.clearPage()

        #Grey banner on top of the page
        banner = tk.Frame(self.tk, bg='#6f7681')
        banner.pack()
        banner.pack_propagate(False)
        banner.configure(width=self.screenWidth, height=100)
        #Text on the banner on the top of the page
        headerText = tk.Label(banner, text="Sign up")
        headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.5, anchor='center')
        #Password entry text box using small light grey text to indicate use
        self.passwordSignUpInput = tk.Entry(self.tk, bd=1,)
        self.passwordSignUpInput.insert(0, "Password")
        self.passwordSignUpInput.place(relx=0.5, rely=0.5, anchor='center', height=60, width=330)
        self.passwordSignUpInput.configure(justify="center")
        self.passwordSignUpInput.configure(fg='grey')
        self.passwordSignUpInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.passwordSignUpInput, type="Password" ))
        self.passwordSignUpInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.passwordSignUpInput, type="Password"))
        #Username entry text box using small light grey text to indicate use.
        self.usernameSignUpInput = tk.Entry(self.tk, bd=1)
        self.usernameSignUpInput.insert(0, "Username")
        self.usernameSignUpInput.place(relx=0.5, rely=0.4, anchor='center', height=60, width=330)
        self.usernameSignUpInput.configure(justify="center")
        self.usernameSignUpInput.configure(fg='grey')
        self.usernameSignUpInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.usernameSignUpInput, type="Username"))
        self.usernameSignUpInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.usernameSignUpInput, type="Username"))
        #Security Question text box used to reset password if lost, also places small light grey text to indicate use.
        self.SecurityQuestionSignUpInput = tk.Entry(self.tk, bd=1)
        self.SecurityQuestionSignUpInput.insert(0, "Security Question")
        self.SecurityQuestionSignUpInput.place(relx=0.5, rely=0.6, anchor='center', height=60, width=330)
        self.SecurityQuestionSignUpInput.configure(justify="center")
        self.SecurityQuestionSignUpInput.configure(fg='grey')
        self.SecurityQuestionSignUpInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.SecurityQuestionSignUpInput, type="securityQuestion"))
        self.SecurityQuestionSignUpInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.SecurityQuestionSignUpInput, type="securityQuestion"))

        self.SecurityAnswerSignUpInput = tk.Entry(self.tk, bd=1)
        self.SecurityAnswerSignUpInput.insert(0, "Security Answer")
        self.SecurityAnswerSignUpInput.place(relx=0.5, rely=0.7, anchor='center', height=60, width=330)
        self.SecurityAnswerSignUpInput.configure(justify="center")
        self.SecurityAnswerSignUpInput.configure(fg='grey')
        self.SecurityAnswerSignUpInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.SecurityAnswerSignUpInput, type="securityAnswer"))
        self.SecurityAnswerSignUpInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.SecurityAnswerSignUpInput, type="securityAnswer"))

        signUpBtn = tk.Button(self.tk, text='Create Account', font=('Bold', self.textsize), command=lambda: self.signUpAccountVerification(self.usernameSignUpInput.get(), self.passwordSignUpInput.get(), self.SecurityQuestionSignUpInput.get(), self.SecurityAnswerSignUpInput.get()))
        signUpBtn.configure(width=13, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        signUpBtn.place(relx=0.6, rely=0.8, anchor='center')

        HaveAccountBtn = tk.Button(self.tk, text='Have Account?', font=('Bold', self.textsize), command=self.logInPage)
        HaveAccountBtn.configure(width=13, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        HaveAccountBtn.place(relx=0.4, rely=0.8, anchor='center')
    def mainPage(self):
        """
        Main menu page that allows the user to open the reset password page, logout, exit, view receipts page, create categories page and remove them.
        """
        if self.UID == None:
            self.logInPage()
        else:
            self.clearPage()
            self.clearBinds()
            banner = tk.Frame(self.tk, bg='#6f7681')
            banner.pack()
            banner.pack_propagate(False)
            banner.configure(width=self.screenWidth, height=100)
            banner.configure(width=self.screenWidth, height=100)

            headerText = tk.Label(banner, text="Menu")
            headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
            headerText.place(relx=0.5, rely=0.5, anchor='center')

            viewReceiptsBtn = tk.Button(self.tk, font=('Bold', self.textsize), text="View Receipts")
            viewReceiptsBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=26, height=2)
            viewReceiptsBtn.place(relx=0.5, rely=0.35, anchor='center')

            signOutBtn = tk.Button(self.tk, image=self.logoutButtonImg, font=('Bold', self.textsize), command=self.signOut)
            signOutBtn.configure(width=70, height=100, bd=0, bg='#6f7681')
            signOutBtn.place(relx=0.9, rely=0.061, anchor='center', )

            exitBtn = tk.Button(self.tk, font=('Bold', self.textsize), image= self.exitButton, command = lambda: self.tk.destroy())
            exitBtn.configure(bd=0, bg='#6f7681', width=70, height=100)
            exitBtn.place(relx=0.97, rely=0.061, anchor='center')

            addReceiptBtn = tk.Button(self.tk, text='Add Receipt', font=('Bold', self.textsize))
            addReceiptBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=26, height=2)
            addReceiptBtn.place(relx=0.5, rely=0.5, anchor='center')

            receiptCategoryBtn = tk.Button(self.tk, text='Add/Remove Category', font=('Bold', self.textsize))
            receiptCategoryBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=26, height=2)
            receiptCategoryBtn.place(relx=0.5, rely=0.65, anchor='center')

            resetPasswordBtn = tk.Button(self.tk, text='Reset Password', font=('Bold', self.textsize), command=self.changeDetailsPage)
            resetPasswordBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=12, height=2)
            resetPasswordBtn.place(relx=0.585, rely=0.8, anchor='center',)

            textSizeText = tk.Label(self.tk, text="Text Size")
            textSizeText.configure(font=('Bold', self.textsize - 2), bg='#6f7681', fg='#ffffff', width=14, height=3, bd=0)
            textSizeText.place(relx=0.42, rely=0.8, anchor='center')
            self.textSizeInput = tk.Entry(textSizeText, bd=1)
            self.textSizeInput.insert(0, self.textsize)
            self.textSizeInput.place(relx=0.88, rely=0.5, anchor='center', height=20, width=35)
            self.textSizeInput.configure(justify="center")
            self.textSizeInput.bind("<FocusOut>", lambda e: self.changeTextSize(self.textSizeInput.get()))
    def forgotPassword(self):
        """
        Page to reset forgotten password
        """
        self.clearPage()

        banner = tk.Frame(self.tk, bg='#6f7681')
        banner.pack()
        banner.pack_propagate(False)
        banner.configure(width=self.screenWidth, height=100)

        headerText = tk.Label(banner, text="Forgot Password")
        headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.5, anchor='center')

        self.usernameResetInput = tk.Entry(self.tk, bd=1)
        self.usernameResetInput.insert(0, "Username")
        self.usernameResetInput.place(relx=0.5, rely=0.5, anchor='center', height=80, width=450)
        self.usernameResetInput.configure(justify="center")
        self.usernameResetInput.configure(fg='grey')
        self.usernameResetInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.usernameResetInput, type="Username"))
        self.usernameResetInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.usernameResetInput, type="Username"))

        resetPasswordBtn = tk.Button(self.tk, text='Reset Password', font=('Bold', self.textsize), command= lambda: self.verifyUsername(self.usernameResetInput.get()))
        resetPasswordBtn.configure(width=15, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        resetPasswordBtn.place(relx=0.61, rely=0.8, anchor='center')
    
        loginPageBtn = tk.Button(self.tk, text='Return', font=('Bold',self.textsize), command=self.logInPage)
        loginPageBtn.configure(width=15, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        loginPageBtn.place(relx=0.39, rely=0.8, anchor='center')
    def securityPage(self, UID, username, securityQuestion, securityAnswer):
        self.clearPage()

        banner = tk.Frame(self.tk, bg='#6f7681')
        banner.pack()
        banner.pack_propagate(False)
        banner.configure(width=self.screenWidth, height=100)

        headerText = tk.Label(banner, text="Reset Password")
        headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.5, anchor='center')

        headerText = tk.Label(self.tk, text=securityQuestion + '?')
        headerText.configure(font=('Bold', 35), bg='#3a414a', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.36, anchor='center')

        self.SecurityAnswerInput = tk.Entry(self.tk, bd=1)
        self.SecurityAnswerInput.insert(0, "Security Answer")
        self.SecurityAnswerInput.place(relx=0.5, rely=0.55, anchor='center', height=90, width=500)
        self.SecurityAnswerInput.configure(justify="center")
        self.SecurityAnswerInput.configure(fg='grey')
        self.SecurityAnswerInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.SecurityAnswerInput, type="securityAnswer"))
        self.SecurityAnswerInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.SecurityAnswerInput, type="securityAnswer"))

        returnPageBtn = tk.Button(self.tk, text='Return', font=('Bold',self.textsize), command=self.logInPage)
        returnPageBtn.configure(width=15, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        returnPageBtn.place(relx=0.4, rely=0.8, anchor='center')

        resetPageBtn = tk.Button(self.tk, text='Reset Password', font=('Bold',self.textsize), command=lambda: self.verifySecurityAnswer(UID, username, self.SecurityAnswerInput.get()))
        resetPageBtn.configure(width=15, height=1, bg='#6f7681', bd=0, fg='#ffffff')
        resetPageBtn.place(relx=0.6, rely=0.8, anchor='center')
    def verifyUsername(self, username):
        userData = functions.verifyAccount(username)
        if userData != None:
            self.securityPage(userData[0], userData[1], userData[3], userData[4])
        elif userData == None:
            messagebox.showerror(title="Account name error", message="User doesn't exist")
    def verifySecurityAnswer(self, UID, username, securityAnswer):
        x = functions.verifyAccount(username)
        if x[4] == securityAnswer:
            print(x[4])
            self.newPasswordPage(UID)

            

    def clearBinds(self):
        """
        Unbinds keys from unfocusing
        """
        self.tk.unbind("<Return>")
        return()
    def changeTextSize(self, newTextSize):
        """
        Changes all font text size except for headers

        Arguments:
        newTextSize(int): New text size that replaces text size integer variable.
        """
        self.textsize = int(newTextSize)
        self.tk.update()
        print("Updated")
        self.mainPage()
    def newPasswordPage(self, UID):
        for frame in self.tk.winfo_children():
            frame.destroy()
        self.clearBinds()
        Backgroundbanner = tk.Frame(self.tk, bg='#4c535d')
        Backgroundbanner.place(anchor='center', relx=0.5, rely= 0.575)
        Backgroundbanner.pack_propagate(False)
        Backgroundbanner.configure(width=self.screenWidth - 170, height=self.screenHeight - 200)
        
        banner = tk.Frame(self.tk, bg='#6f7681')
        banner.pack()
        banner.pack_propagate(False)
        banner.configure(width=self.screenWidth, height=100)

        headerText = tk.Label(banner, text="Reset Password")
        headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.5, anchor='center')

        self.newPasswordInput = tk.Entry(self.tk, bd=1,)
        self.newPasswordInput.insert(0, "New Password")
        self.newPasswordInput.place(relx=0.5, rely=0.5, anchor='center', height=60, width=330)
        self.newPasswordInput.configure(justify="center")
        self.newPasswordInput.configure(fg='grey')
        self.newPasswordInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.newPasswordInput, type="New Password" ))
        self.newPasswordInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.newPasswordInput, type="New Password"))
        
        dontSaveBtn = tk.Button(self.tk, text='Return', font=('Bold', self.textsize), command=self.logInPage)
        dontSaveBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=12, height=2)
        dontSaveBtn.place(relx=0.4, rely=0.8, anchor='center',)

        saveBtn = tk.Button(self.tk, text='Save Password', font=('Bold', self.textsize), command=lambda: [functions.saveNewDetails(UID, self.newPasswordInput.get(), "None"), self.logInPage()])
        saveBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=12, height=2)
        saveBtn.place(relx=0.585, rely=0.8, anchor='center',)

    def changeDetailsPage(self):
        
        """
        Page that allows the user to change their username and password for your account
        """

        for frame in self.tk.winfo_children():
            frame.destroy()
        self.clearBinds()
        Backgroundbanner = tk.Frame(self.tk, bg='#4c535d')
        Backgroundbanner.place(anchor='center', relx=0.5, rely= 0.575)
        Backgroundbanner.pack_propagate(False)
        Backgroundbanner.configure(width=self.screenWidth - 170, height=self.screenHeight - 200)
        
        banner = tk.Frame(self.tk, bg='#6f7681')
        banner.pack()
        banner.pack_propagate(False)
        banner.configure(width=self.screenWidth, height=100)

        headerText = tk.Label(banner, text="Change Password/Username")
        headerText.configure(font=('Bold', 35), bg='#6f7681', fg='#ffffff')
        headerText.place(relx=0.5, rely=0.5, anchor='center')

        self.newPasswordInput = tk.Entry(self.tk, bd=1,)
        self.newPasswordInput.insert(0, "New Password")
        self.newPasswordInput.place(relx=0.5, rely=0.5, anchor='center', height=60, width=330)
        self.newPasswordInput.configure(justify="center")
        self.newPasswordInput.configure(fg='grey')
        self.newPasswordInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.newPasswordInput, type="New Password" ))
        self.newPasswordInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.newPasswordInput, type="New Password"))

        self.newUsernameInput = tk.Entry(self.tk, bd=1,)
        self.newUsernameInput.insert(0, "New Username")
        self.newUsernameInput.place(relx=0.5, rely=0.4, anchor='center', height=60, width=330)
        self.newUsernameInput.configure(justify="center")
        self.newUsernameInput.configure(fg='grey')
        self.newUsernameInput.bind('<FocusIn>', lambda e: self.onClick(textbox=self.newUsernameInput, type="New Username" ))
        self.newUsernameInput.bind('<FocusOut>', lambda e: self.focusout(textbox=self.newUsernameInput, type="New Username"))
        
        saveBtn = tk.Button(self.tk, text='Save', font=('Bold', self.textsize), command=lambda: [functions.saveNewDetails(self.UID, self.newPasswordInput.get(), self.newUsernameInput.get()), self.mainPage()])
        saveBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=12, height=2)
        saveBtn.place(relx=0.585, rely=0.8, anchor='center',)

        dontSaveBtn = tk.Button(self.tk, text='Dont Save', font=('Bold', self.textsize), command=self.mainPage)
        dontSaveBtn.configure(bg='#6f7681', bd=0, fg='#ffffff', width=12, height=2)
        dontSaveBtn.place(relx=0.4, rely=0.8, anchor='center',)
        
window = GUIWindow()

