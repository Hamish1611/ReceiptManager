#Version 1 Created by Hamish Grogan
#Last Modified Project on 18/7/2024 (DD/MM/YYYY)

import GUIModule
GUIObject = GUIModule.GUIWindow
