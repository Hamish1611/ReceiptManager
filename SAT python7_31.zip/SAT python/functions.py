import os
import random
import csv
def loginVerification(username, password):
    print(f"Username: {username}\nPassword: {password}")
    with open('data//userData.csv', 'r') as f:
        csv_reader = csv.reader(f, delimiter=',')
        for row in csv_reader:
            if row[1] == username and row[2] == password:
                return row[0]
    return None
def saveData(username, password, UID):
    pass
def verifyAccount(username):
    with open('data//userData.csv', 'r') as file:
        csv_reader = csv.reader(file, delimiter=',')
        for row in csv_reader:
            if row[1] == username:
                return row
    return None

def createAccount(username, password, securityQuestion, securityAnswer):
    """
    Creates new user account
    """
    with open("data//userData.csv", 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            try:
                if row[1].lower() == str(username).lower():
                    return None
            except:
                if row == '':
                    print("Row Empty")
                    continue
    while True:
        generatedID = random.randint(10000, 100000)
        with open(f"data//userData.csv", "r") as file:
            userDataFile = csv.reader(file)
            for line in userDataFile:
                if generatedID in line:
                    continue
            UID = generatedID
            break
    securityQuestion = str(securityQuestion).replace("?" , "")
    os.mkdir(f"data//users//{UID}")
    os.mkdir(f"data//users//{UID}//receipts")
    with open(f"data//users//{UID}//receipts.csv", 'w') as file:
        file.close()
    with open(f"data//users//{UID}//accDetails.csv", 'w') as file:
        file.close()
    
    with open(f"data//userData.csv", "a") as file:
        file.write(f"{UID},{username},{password},{securityQuestion},{securityAnswer}\n")
    print("User Created")
    return UID
def saveNewDetails(UID, password, username):
    with open(f"data//userData.csv", "r") as readFile:
            rowNum = 0
            userDataFile = csv.reader(readFile)
            for row in userDataFile:
                rowNum += 1
                if row[0] == UID:
                    with open("data//userData.csv", 'w') as writeFile:
                        row[2] = password
                        if username != "None":
                            print("Didn't work")
                            row[1] = username
    
